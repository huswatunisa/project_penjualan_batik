function hanyaAngka(evt) {
    var charCode = (evt.which) ? evt.which :event.keyCode
    if (charcode > 31 && (charcode < 48 || charcode > 57))
        return false;
    return true;
}

function validasi_inputbarang(form) {
    if (from.kode.value == "") {
        alert("Kode Barang masih kosong!");
        form.kode.focus();
        return (false);
    } else if (form.nama.value == "") {
        alert("Nama Barang masih kosong!");
        form.nama.focus();
        return(false);
    } else if (form.harga.value == "") {
        alert("Harga masih kosong!");
        form.hargs.focus();
        return (false);
    } else if (form.stok.value == "") {
        alert("Stok masih kosong!");
        form.stok.focus();
        return (false);
    }
    return(true);
}
function validasi_inputAkun(form){
    if(from.no_akun.value=="") {
        alert("Nomer Akun masih kosong!");
        form.no_akun.focus();
        return(false);
    } else if (form.nm_akun.value=="") {
        alert("Nama Akun masih kosong!");
        form.nm_akun.focus();
        return(false);
    }
    return(true);
}
function validasi_inputUser(form){
    if(from.id_user.value=="") {
        alert("Id User masih kosong!");
        form.id_user.focus();
        return(false);
    } else if (form.nm_user.value=="") {
        alert("Nama user masih kosong!");
        form.nm_user.focus();
        return(false);
    } else if (form.password.value=="") {
        alert("password masih kosong!");
        form.password.focus();
        return (false);
    }
    else if (form.hak_akses.value=="") {
        alert("Nama user masih kosong!");
        form.hak_akses.focus();
        return(false);
    }
    return(true);
}
function validasi_inputpelanggan(form){
    if(from.id.value=="") {
        alert("Id pelanggan masih kosong!");
        form.id.focus();
        return(false);
    } else if (form.nama.value=="") {
        alert("Nama pelanggan masih kosong!");
        form.nama.focus();
        return(false);
    } else if (form.alamat.value=="") {
        alert("alamat masih kosong!");
        form.alamat.focus();
        return (false);
    }else if (form.telepon.value=="") {
        alert("telepon masih kosong!");
        form.telepon.focus();
        return (false);
    }
    return(true);
}

function pesan() {
     document.getElementById("nopesan").value =  document.getElementById("nopes").value;
    }

function showEmp(Id)
    {
        if (document.getElementById("kode").value !== "-1")
        {
            xmlHttp = new XMLHttpRequest();
            if (xmlHttp === null)
            {
                alert("Browser does not support HTTP Request");
                return;
            }
            var url = "getbarang.jsp";
            url = url + "?emp_id=" + document.getElementById("kode").value;
            xmlHttp.onreadystatechange = stateChanged;
            xmlHttp.open("GET", url, true);
            xmlHttp.send(null);
        } else
        {
            alert("Pilih Kode Barang");
        }
    }

function stateChanged()
    {
        document.getElementById("ename").value = "";
        document.getElementById("emp_id").value = "";
    
        if (xmlHttp.readyState === 4 || xmlHttp.readyState === "complate")
        {
            
            var showdata = xmlHttp.responseText;
            var strar = showdata.split(":");
            console.log(strar);
            if (strar.length === 1)
            {
                console.log("masuk state");
                document.getElementById("emp_id").focus();
                alert("Pilih Kode Barang");
                document.getElementById("ename").value = " ";
                document.getElementById("emp_id").value = " ";
            } else if (strar.length > 1)
            {
                console.log("masuk state");
                document.getElementById("ename").value = strar[1];
            }
        }
    }
    function sumPesan() {
        var txtFirstNumberValue = document.getElementById('ename').value;
        var txtSecondNumberValue = document.getElementById('jml').value;
        var result = parseFloat(txtFirstNumberValue) * parseFloat(txtSecondNumberValue);
        if (!isNaN(result)) {
            document.getElementById('subtotal').value = result;
        }
    }
    
            
         